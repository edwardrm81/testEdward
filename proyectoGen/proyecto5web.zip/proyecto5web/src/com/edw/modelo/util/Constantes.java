/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.edw.modelo.util;

/**
 *
 * @author Edward
 */

public class Constantes {
    public final static String ESTADO1 = "1";
    
    public final static String ERROR_BD = "Ha ocurrido un error inesperado de Base de Datos";
    public final static String ERROR_SYSTEMA = "Ha ocurrido un error inesperado del sistema";
    
}
