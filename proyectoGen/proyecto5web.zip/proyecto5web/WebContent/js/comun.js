
function onLoadComun(){
	;
}

