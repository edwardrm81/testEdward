package com.edw.gen.apigen;

public class ExcepcionNegocio extends Exception {

	public ExcepcionNegocio(String mensajeExcepcion) {
		super(mensajeExcepcion);
	}

}
